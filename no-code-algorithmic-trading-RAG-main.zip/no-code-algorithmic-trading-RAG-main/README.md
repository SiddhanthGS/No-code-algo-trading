week 1: Intro to LangChain and RAG
https://www.youtube.com/watch?v=1bUy-1hGZpI&pp=ygUPbGVhcm4gbGFuZ2NoYWlu
https://www.youtube.com/watch?v=T-D1OfcDW1M&t=3s&pp=ygUDcmFn
https://www.youtube.com/watch?v=sVcwVQRHIc8&pp=ygUDcmFn
https://python.langchain.com/docs/tutorials/agents/#installation

week 2: Connecting tools to LangChain
https://www.youtube.com/watch?v=ziu87EXZVUE&pp=ygUPbGFuZ2NoYWluIHRvb2xz
https://www.youtube.com/watch?v=zCwuAlpQKTM&t=331s&pp=ygUPbGFuZ2NoYWluIHRvb2xz
https://www.youtube.com/watch?v=biS8G8x8DdA&t=11s&pp=ygUPbGFuZ2NoYWluIHRvb2xz
https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://python.langchain.com/docs/integrations/tools/human_tools/&ved=2ahUKEwjXt8XT6rqJAxWJd2wGHTwzLhcQFnoECAoQAQ&usg=AOvVaw1BfqfU_R7qAQf6NJZn6nfN
https://python.langchain.com/v0.1/docs/modules/tools/

week 3: Getting started with algorithmic trading (using backtrader) and connecting it's documentation to LangChain
https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://www.investopedia.com/articles/active-trading/101014/basics-algorithmic-trading-concepts-and-examples.asp&ved=2ahUKEwip2db26rqJAxURqVYBHbxjH50QFnoECCIQAQ&usg=AOvVaw2Ymsb7bF1jtSzIO61Loy6y
https://www.backtrader.com/docu/

week 4: Finishing the project and converting our project to webapp using Mercury
https://www.youtube.com/watch?v=RgkRf6dbTy8&pp=ygUObWVyY3VyeSBweXRob24%3D
https://www.youtube.com/watch?v=X5FHzx7r254&t=543s&pp=ygUObWVyY3VyeSBweXRob24%3D
https://cloud.runmercury.com
https://www.google.com/url?sa=t&source=web&rct=j&opi=89978449&url=https://runmercury.com/docs/&ved=2ahUKEwjOqtrU67qJAxWdSWwGHbUUA2YQFnoECAoQAQ&usg=AOvVaw20QYNfwNkXr0oMuZQ8GE5Y
